-- Adminer 4.2.2 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `cmo_donation_table`;
CREATE TABLE `cmo_donation_table` (
  `nid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `i_am` varchar(20) DEFAULT NULL,
  `pancard` varchar(10) DEFAULT NULL,
  `tinnumber` varchar(12) DEFAULT NULL,
  `mobile` varchar(10) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `amount` varchar(15) DEFAULT NULL,
  `payment_mode` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`nid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='The base table for CMO Donation module.';

INSERT INTO `cmo_donation_table` (`nid`, `name`, `i_am`, `pancard`, `tinnumber`, `mobile`, `email`, `amount`, `payment_mode`) VALUES
(1,	'Robin',	'indivi',	'7877787878',	'',	'8998989988',	'robin@silvertouch.com',	'100000',	'debit_credit_card'),
(2,	'rooi',	'indivi',	'8989898',	'',	'8989889898',	'rr@gmail.com',	'100',	'debit_credit_card');

-- 2017-09-04 05:58:06
